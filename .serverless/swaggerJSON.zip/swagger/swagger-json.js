"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// swagger/swagger.js
var require_swagger = __commonJS({
  "swagger/swagger.js"(exports2, module2) {
    module2.exports = {
      "swagger": "2.0",
      "info": {
        "title": "shop-api",
        "version": "1"
      },
      "paths": {
        "/products": {
          "get": {
            "summary": "getProductsList",
            "description": "",
            "operationId": "getProductsList.get.products",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [],
            "responses": {
              "200": {
                "description": "Success response",
                "schema": {
                  "$ref": "#/definitions/Product"
                }
              }
            }
          }
        },
        "/products/{id}": {
          "get": {
            "summary": "getProductsById",
            "description": "",
            "operationId": "getProductsById.get.products/{id}",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [
              {
                "name": "id",
                "in": "path",
                "required": true,
                "type": "string"
              }
            ],
            "responses": {
              "200": {
                "description": "Success response",
                "schema": {
                  "$ref": "#/definitions/Product"
                }
              }
            }
          }
        },
        "/products/": {
          "post": {
            "summary": "createProduct",
            "description": "",
            "operationId": "createProduct.post.products/",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [],
            "responses": {
              "200": {
                "description": "Success response",
                "schema": {
                  "$ref": "#/definitions/Product"
                }
              }
            }
          }
        },
        "/import/{name}": {
          "get": {
            "summary": "importProductsFile",
            "description": "",
            "operationId": "importProductsFile.get.import/{name}",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [
              {
                "name": "name",
                "in": "path",
                "required": true,
                "type": "string"
              }
            ],
            "responses": {
              "200": {
                "description": "Success response",
                "schema": {
                  "$ref": "#/definitions/Product"
                }
              }
            }
          }
        }
      },
      "definitions": {
        "Product": {
          "properties": {
            "id": {
              "title": "Product.id",
              "type": "string"
            },
            "title": {
              "title": "Product.title",
              "type": "string"
            },
            "count": {
              "title": "Product.count",
              "type": "number"
            },
            "description": {
              "title": "Product.description",
              "type": "string"
            },
            "price": {
              "title": "Product.price",
              "type": "number"
            }
          },
          "required": [
            "id",
            "title",
            "count",
            "description",
            "price"
          ],
          "additionalProperties": false,
          "title": "Product",
          "type": "object"
        }
      },
      "securityDefinitions": {}
    };
  }
});

// swagger/swagger-json.js
var swagger = require_swagger();
exports.handler = async () => {
  return {
    statusCode: 200,
    body: JSON.stringify(swagger)
  };
};
//# sourceMappingURL=swagger-json.js.map
